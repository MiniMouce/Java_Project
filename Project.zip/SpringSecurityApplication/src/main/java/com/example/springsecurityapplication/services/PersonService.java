package com.example.springsecurityapplication.services;

import com.example.springsecurityapplication.enumm.Role;
import com.example.springsecurityapplication.models.Person;
import com.example.springsecurityapplication.models.Product;
import com.example.springsecurityapplication.repositories.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class PersonService {
    private final PersonRepository personRepository;
    private final PasswordEncoder passwordEncoder;
@Autowired
    public PersonService(PersonRepository personRepository, PasswordEncoder passwordEncoder) {
        this.personRepository = personRepository;
        this.passwordEncoder = passwordEncoder;
}

    public List<Person> getAllPerson(){
        return (List<Person>) personRepository.findAll();
    }

    public Person findByLogin(Person person){
    Optional<Person> person_db = personRepository.findByLogin(person.getLogin());
    return person_db.orElse(null);
    }

    public Person findById(int id){
        Optional<Person> person_db = personRepository.findById(id);
        return person_db.orElse(null);
    }

    @Transactional
    public void register(Person person){
    person.setPassword(passwordEncoder.encode((person.getPassword())));
    person.setRole(Role.valueOf("ROLE_USER"));
    personRepository.save(person);
    }
}
