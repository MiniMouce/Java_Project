package com.example.springsecurityapplication.config;

import com.example.springsecurityapplication.services.PersonDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled = true)
// public class SecurityConfig extends WebSecurityConfiguration {
public class SecurityConfig extends WebSecurityConfigurerAdapter {

//    private final AuthenticationProvider authenticationProvider;
//
//
//    public SecurityConfig(AuthenticationProvider authenticationProvider) {
//        this.authenticationProvider = authenticationProvider;
//    }

    private final PersonDetailService personDetailService;

    @Autowired
    public SecurityConfig(PersonDetailService personDetailService) {
        this.personDetailService = personDetailService;
    }


   // конфигурируем  SpringSecurity
    @Override
    protected void configure (HttpSecurity httpSecurity) throws Exception{
        //указываем на какой урл адрес фильтр спрнгсекьюрити будет отправляться неаутенцифицированного пользователя на  защищенную старницу
        httpSecurity
                // все страницы будут защищены процессом аутентификации

                .authorizeRequests()
                .antMatchers("/admin").hasRole("ADMIN") //указываем что страница /admin доступна пользваотелю с ролью ADMIN
                .antMatchers("/authentication/login", "/authentication/registration", "/error", "/product", "/img/**", "/product/info/{id}", "/index", "/css/**", "/fonts/**", "/js/**", "/product/search").permitAll() // указываем что эта страница доступна для пользователя
                .anyRequest().hasAnyRole("USER", "ADMIN")//указываем что все остальные страницы доступны пользвоателям с ролью user, admin


               // .anyRequest().authenticated() //указываем что для всех остальных страниц необходимо вызывать метод authenticated() который открывает форму аутентификации
                .and()
                .formLogin().loginPage("/authentication/login")
                // указываем на какой урл будут отправляться данные с формы аутентификации
                .loginProcessingUrl("/process_login")
                // указываем на какой урл необходимо направить пользователя после успешной аутентификации
                .defaultSuccessUrl("/index", true)
                // куда надо перейти при неверной аутентификации
                .failureUrl("/authentication/login?error")

                .and()
                .logout().logoutUrl("/logout").logoutSuccessUrl("/authentication/login");
    }

    // Данный метод позволяет настроить аутентификацию
        protected void configure (AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
//        authenticationManagerBuilder.authenticationProvider(authenticationProvider);

        authenticationManagerBuilder.userDetailsService(personDetailService)
            .passwordEncoder(getPasswordEncoder());
    }

    @Bean
    public PasswordEncoder getPasswordEncoder(){
        return new BCryptPasswordEncoder();
    }
}
