package com.example.springsecurityapplication.enumm;

public enum Status {
    Принят("P"), Оформлен("O"), Оплачен("Op"), В_пути("V"), Ожидает("Ozh"), Получен("Pol");

    private String code;

    private Status(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
