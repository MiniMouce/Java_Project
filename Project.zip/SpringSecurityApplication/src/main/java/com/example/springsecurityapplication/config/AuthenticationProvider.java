//package com.example.springsecurityapplication.config;
//
//import com.example.springsecurityapplication.services.PersonDetailService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.AuthenticationException;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.stereotype.Component;

//import java.util.Collections;
//
//@Component
//public class AuthenticationProvider implements org.springframework.security.authentication.AuthenticationProvider {
//
//    private final PersonDetailService personDetailService;
//
//    @Autowired
//    public AuthenticationProvider(PersonDetailService personDetailService) {
//        this.personDetailService = personDetailService;
//    }
//
//    @Override
//    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
//        String login = authentication.getName();
//
//        //Получаем запись найденного пользователяпо логину
//        UserDetails person = personDetailService.loadUserByUsername(login);
//        String password = authentication.getCredentials().toString();
//
//        if(!password.equals(person.getPassword()))
//        {
//            throw new BadCredentialsException("Некорректный пароль");
//        }
//        // Возвращаем объект аутентификации В данном объекте будет лежать объект модели, парль, права доступа -> пока ролей нет
//        // Данный объект будет помещен в сессию
//        return new UsernamePasswordAuthenticationToken(person, password, Collections.emptyList());
//    }
//
//    @Override
//    public boolean supports(Class<?> authentication) {
//        return true;
//    }
//}
