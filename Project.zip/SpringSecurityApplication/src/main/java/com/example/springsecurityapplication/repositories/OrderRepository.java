package com.example.springsecurityapplication.repositories;

import com.example.springsecurityapplication.enumm.Status;
import com.example.springsecurityapplication.models.Order;
import com.example.springsecurityapplication.models.Person;
import com.example.springsecurityapplication.models.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
@Transactional

public interface OrderRepository extends JpaRepository <Order, Integer>, PagingAndSortingRepository<Order, Integer> {

    List<Order> findByPerson(Person person);
    List<Order> findAll();

    @Modifying
    @Query(value = "update Order orders set orders.status = :status where orders.id = :id")
    void updateStatusById (Status status, int id);

    @Query(value = "SELECT * from orders where right (orders.number, 4) = :num", nativeQuery = true)
    List<Order> findByFourLastSymbolsNumberOrder (String num);
    }

