package com.example.springsecurityapplication.models;

import com.example.springsecurityapplication.enumm.Role;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
@Table(name = "Person")
public class Person {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotEmpty(message = "Логин не может быть пустым")
    @Size(min = 5, max = 100, message = "Логин должен быть от 5 до 100 символов")
    @Column(name = "login")
    private String login;


    @NotEmpty(message = "Пароль не может быть пустым")
    //@Size(min = 5, max = 100, message = "Пароль должен быть от  до 100 символов")
    @Column(name = "password")
    // @Max(value = 100, message="Пароль не может быть больше 100 символов")
    @Pattern(regexp = "(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\\n])(?=.*[A-Z])(?=.*[a-z]).*$", message = "Пароль должен содержать хотя бы 1 цифру, букву в вехнем регистре и нижнем регистре, количество от 8 символов")
    private String password;

    @Column(name = "role")
    private Role role;

    @ManyToMany
    @JoinTable(name = "product_cart", joinColumns = @JoinColumn(name = "person_id"), inverseJoinColumns = @JoinColumn(name = "product_id"))
    private List<Product> product;

    @OneToMany(mappedBy = "person")
    private List<Order> orderList;

    public Person() {
    }

    public Person(int id, String login, String password) {
        this.id = id;
        this.login = login;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Person(String login, String password, Role role, List<Product> product, List<Order> orderList) {
        this.login = login;
        this.password = password;
        this.role = role;
        this.product = product;
        this.orderList = orderList;
    }
}